#! /bin/bash
# declare STRING variable

STRING="Hello World!"
# print variable on a screen
echo $STRING

OF=$(date+%Y%m%d).tar.gz
tar -czf $OF hello.sh